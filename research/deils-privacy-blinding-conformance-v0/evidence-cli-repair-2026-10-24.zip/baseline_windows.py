from pathlib import Path
import subprocess,json,os,sys,hashlib
root=Path(__file__).resolve().parent/'kit-baseline';out=Path(__file__).resolve().parent/'kit-baseline-windows';out.mkdir(exist_ok=False)
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']=str(Path(sys.executable).parent)+os.pathsep+env['PATH']
rows=[]
for name in ['test_conformance_suite_shapes.py','test_run_conformance_runtime_preconditions.py']:
    cmd=[sys.executable,'-B','tools/'+name];p=subprocess.run(cmd,cwd=root,env=env,capture_output=True)
    (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
    rows.append(dict(command=cmd,exit=p.returncode,source_sha256=hashlib.sha256((root/'tools'/name).read_bytes()).hexdigest()))
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(rows,indent=2))
