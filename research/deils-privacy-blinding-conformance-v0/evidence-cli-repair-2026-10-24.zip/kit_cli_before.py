import hashlib,json,subprocess,tempfile
from pathlib import Path
root=Path('D:/PAVLO HQ/Workspaces/deils-privacy-blinding-conformance-v0/research/deils-privacy-blinding-conformance-v0')
rows=[]
with tempfile.TemporaryDirectory() as td:
    physical=Path(td).resolve()/'physical';physical.mkdir()
    (physical/'verifier.mjs').write_bytes((root/'verifier.mjs').read_bytes())
    linked=Path(td).resolve()/'linked';linked.symlink_to(physical,target_is_directory=True)
    for label,path in [('direct',physical),('symlink',linked)]:
        p=subprocess.run(['node',str(path/'verifier.mjs')],input=(root/'vectors.json').read_bytes(),capture_output=True)
        rows.append(dict(label=label,symlink=linked.is_symlink(),command=p.args,exit=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),sha256=hashlib.sha256(p.stdout).hexdigest()))
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps([{k:v for k,v in r.items() if k not in ['stdout']}|{'stdout_bytes':len(r['stdout'])} for r in rows],indent=2))
